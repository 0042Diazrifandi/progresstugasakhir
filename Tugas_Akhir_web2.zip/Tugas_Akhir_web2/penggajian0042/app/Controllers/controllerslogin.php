<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class controllerslogin extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    /**
     * Menampilkan halaman login.
     */
    public function login()
    {
        return view('login'); // File view: app/Views/login.php
    }

    /**
     * Memproses login pengguna.
     */
    public function loginProcess()
    {
        // Ambil data dari form
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Cari pengguna berdasarkan username
        $user = $this->userModel->getUserByUsername($username);

        if ($user) {
            // Verifikasi password
            if (password_verify($password, $user['password'])) {
                // Simpan data pengguna ke session
                session()->set([
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'logged_in' => true,
                ]);

                // Redirect ke halaman dashboard
                return redirect()->to('/dashboard');
            } else {
                return redirect()->back()->with('error', 'Password salah.');
            }
        } else {
            return redirect()->back()->with('error', 'Username tidak ditemukan.');
        }
    }

    /**
     * Logout pengguna.
     */
    public function logout()
    {
        session()->destroy(); // Hapus semua data session
        return redirect()->to('/login'); // Redirect ke halaman login
    }
}