<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class HakAkses extends Migration
{
    public function up()
    {
        //
        $this->forge->addField([
            'id_akses' => [
                'type' => 'INT',
                'constraint' => 11,
                'unsigned' => true,
                'auto_increment' => true
            ],
            'keterangan' => [
                'type' => 'VARCHAR',
                'constraint' => 50
            ],
            'hak_akses' => [
                'type' => 'INT',
                'constraint' => 11
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('hak_akses');
        
    }

    public function down()
    {
        //
        $this->forge->dropTable('pegawai');
        $this->forge->dropTable('data_kehadiran');
        $this->forge->dropTable('potongan_gaji');
        $this->forge->dropTable('data_jabatan');
        $this->forge->dropTable('hak_akses');
    }
}
