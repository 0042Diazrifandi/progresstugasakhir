<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users'; // Nama tabel database
    protected $primaryKey = 'id'; // Primary key
    protected $allowedFields = ['username', 'password']; // Kolom yang diizinkan untuk diakses

    /**
     * Mencari pengguna berdasarkan username.
     *
     * @param string $username
     * @return array|null
     */
    public function getUserByUsername($username)
    {
        return $this->where('username', $username)->first();
}
}