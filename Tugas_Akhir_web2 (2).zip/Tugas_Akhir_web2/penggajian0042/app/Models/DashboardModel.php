<?php

namespace App\Models;

use CodeIgniter\Model;

class DashboardModel extends Model
{
    protected $table = 'pegawai'; // Ganti dengan tabel yang sesuai di database Anda
    protected $primaryKey = 'id_pegawai'; // Ganti dengan primary key tabel Anda
    protected $allowedFields = ['type', 'count']; // Ganti dengan kolom-kolom tabel Anda

    public function getDashboardData()
    {
        return $this->findAll();
    }

    public function getCountByType($type)
    {
        return $this->where('type', $type)->first();
    }
}
