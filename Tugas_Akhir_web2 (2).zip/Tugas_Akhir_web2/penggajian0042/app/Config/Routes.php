<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'controllerslogin::login'); // Menampilkan halaman login
$routes->post('/login', 'controllerslogin::loginProcess'); // Memproses login
$routes->get('/logout', 'controllerslogin::logout'); // Logout pengguna



$routes->get('/dashboard', 'DashboardAdminController::index');