<?php

namespace App\Controllers;

use App\Models\PegawaiModel; // Pastikan nama model benar
use CodeIgniter\Controller;

class Controllerslogin extends BaseController
{
    protected $pegawaiModel;

    public function __construct()
    {
        $this->pegawaiModel = new PegawaiModel(); // Gunakan nama model yang benar
    }

    /**
     * Menampilkan halaman login.
     */
    public function login()
    {
        return view('login'); // File view: app/Views/login.php
    }

    /**
     * Memproses login pengguna.
     */
    public function loginProcess()
    {
        // Ambil data dari form
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Cari pengguna berdasarkan username
        $pegawai = $this->pegawaiModel->where('username', $username)->first();

        if ($pegawai) {
            // Verifikasi password
            if (password_verify($password, $pegawai['password'])) {
                // Simpan data pengguna ke session
                session()->set([
                    'id' => $pegawai['id'],
                    'username' => $pegawai['username'],
                    'logged_in' => true,
                ]);

                // Redirect ke halaman dashboard
                return redirect()->to('/dashboard');
            } else {
                return redirect()->back()->with('error', 'Password salah.');
            }
        } else {
            return redirect()->back()->with('error', 'Username tidak ditemukan.');
        }
    }

    /**
     * Logout pengguna.
     */
    public function logout()
    {
        session()->destroy(); // Hapus semua data session
        return redirect()->to('/login'); // Redirect ke halaman login
    }
}
